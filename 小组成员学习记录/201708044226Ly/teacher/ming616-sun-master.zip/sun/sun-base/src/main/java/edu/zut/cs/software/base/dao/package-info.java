/**
 * Data Access Object (dao) Base Classes
 * 
 * @author liuxiaoming
 *
 */
package edu.zut.cs.software.base.dao;