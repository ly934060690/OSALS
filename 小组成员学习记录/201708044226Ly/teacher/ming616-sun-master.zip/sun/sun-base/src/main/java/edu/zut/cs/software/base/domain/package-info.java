/**
 * 领域实体基类
 *
 * @author liuxiaoming
 */
/**
 * @author liuxiaoming
 *
 */
package edu.zut.cs.software.base.domain;