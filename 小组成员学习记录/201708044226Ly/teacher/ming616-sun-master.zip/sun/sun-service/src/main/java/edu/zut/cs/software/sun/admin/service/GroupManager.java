package edu.zut.cs.software.sun.admin.service;

import edu.zut.cs.software.base.service.GenericTreeManager;
import edu.zut.cs.software.sun.admin.domain.Group;

public interface GroupManager extends GenericTreeManager<Group, Long> {

}
