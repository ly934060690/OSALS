package edu.zut.cs.software.sun.admin.dao;

import edu.zut.cs.software.base.dao.GenericDao;
import edu.zut.cs.software.sun.admin.domain.User;

public interface UserDao extends GenericDao<User, Long> {
}
