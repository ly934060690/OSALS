/**
 * 
 */
/**
 * @author liuxiaoming
 *
 */
package edu.zut.cs.software.sun.admin.domain;