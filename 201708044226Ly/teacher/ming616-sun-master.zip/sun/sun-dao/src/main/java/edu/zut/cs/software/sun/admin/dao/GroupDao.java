package edu.zut.cs.software.sun.admin.dao;

import edu.zut.cs.software.base.dao.GenericTreeDao;
import edu.zut.cs.software.sun.admin.domain.Group;

public interface GroupDao extends GenericTreeDao<Group, Long> {

}
